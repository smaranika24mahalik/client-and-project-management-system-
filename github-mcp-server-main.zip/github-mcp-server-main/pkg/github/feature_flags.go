package github

import (
	"slices"

	"github.com/github/github-mcp-server/v2/pkg/inventory"
)

// MCPAppsDisableFormDeferralFeatureFlag disables handing write-tool calls off
// to MCP App forms while preserving MCP Apps UI metadata and result views.
const MCPAppsDisableFormDeferralFeatureFlag = "mcp_apps_disable_form_deferral"

// FeatureFlagCSVOutput is the feature flag name for CSV output on list tools.
const FeatureFlagCSVOutput = "csv_output"

// FeatureFlagIFCLabels is the feature flag name for IFC security labels in tool results.
const FeatureFlagIFCLabels = "ifc_labels"

// FeatureFlagFileBlame is the feature flag name for the get_file_blame tool,
// which exposes git blame information for a file. It is gated so the extra tool
// is not advertised by default, keeping the tool surface small unless opted in.
const FeatureFlagFileBlame = "file_blame"

// FeatureFlagIssueDependencies is the feature flag name for the issue dependency
// tools (issue_dependency_read / issue_dependency_write), which read and edit an
// issue's blocked-by / blocking relationships. It is gated so these tools are not
// advertised in the default surface, keeping the fixed tool-schema cost small
// unless explicitly opted in.
const FeatureFlagIssueDependencies = "issue_dependencies"

// FeatureFlagDuplicateDetection is the feature flag name for the find_duplicate
// tool, which returns ranked duplicate candidates for an existing issue. It is
// gated so the extra tool is not advertised by default, and is deliberately
// excluded from insiders mode so duplicate detection is only ever an explicit
// opt-in.
const FeatureFlagDuplicateDetection = "duplicate_detection"

// FeatureFlagThreadResolutionReason exposes resolution reasons for Copilot review threads.
const FeatureFlagThreadResolutionReason = "thread_resolution_reason"

// AllowedFeatureFlags is the allowlist of feature flags that can be enabled
// by users via --features CLI flag, X-MCP-Features HTTP header, or the
// features URL query parameter.
// Only flags in this list are accepted; unknown flags are silently ignored.
// This is the single source of truth for which flags are user-controllable.
var AllowedFeatureFlags = []string{
	MCPAppsDisableFormDeferralFeatureFlag,
	FeatureFlagCSVOutput,
	FeatureFlagIFCLabels,
	FeatureFlagIssuesGranular,
	FeatureFlagPullRequestsGranular,
	FeatureFlagFileBlame,
	FeatureFlagIssueDependencies,
	FeatureFlagDuplicateDetection,
	FeatureFlagThreadResolutionReason,
}

// InsidersFeatureFlags is the list of feature flags that insiders mode enables.
// When insiders mode is active, all flags in this list are treated as enabled.
// This is the single source of truth for what "insiders" means in terms of
// feature flag expansion.
var InsidersFeatureFlags = []string{
	FeatureFlagCSVOutput,
	FeatureFlagFileBlame,
	FeatureFlagIssueDependencies,
}

// FeatureFlags defines runtime feature toggles that adjust tool behavior.
type FeatureFlags struct {
	LockdownMode bool
}

func featureEnabledRule(feature string) inventory.FeatureRule {
	flag := inventory.FeatureFlag(feature)
	return inventory.NewFeatureRule(
		[]inventory.FeatureFlag{flag},
		func(featureAsBool inventory.FeatureResolver) bool {
			return featureAsBool(flag)
		},
	)
}

func featureDisabledRule(feature string) inventory.FeatureRule {
	flag := inventory.FeatureFlag(feature)
	return inventory.NewFeatureRule(
		[]inventory.FeatureFlag{flag},
		func(featureAsBool inventory.FeatureResolver) bool {
			return !featureAsBool(flag)
		},
	)
}

var (
	issuesGranularFeatureRule       = featureEnabledRule(FeatureFlagIssuesGranular)
	issuesConsolidatedFeatureRule   = featureDisabledRule(FeatureFlagIssuesGranular)
	pullRequestsGranularFeatureRule = featureEnabledRule(FeatureFlagPullRequestsGranular)
	pullRequestsConsolidatedRule    = featureDisabledRule(FeatureFlagPullRequestsGranular)
)

// ResolveFeatureFlags computes the effective set of enabled feature flags by:
//  1. Taking the user-supplied flags (from --features or HTTP request
//     configuration) and
//     keeping only those present in AllowedFeatureFlags. Unknown or unsafe
//     flags from request input are silently dropped here.
//  2. If insiders mode is on, unioning in every flag from InsidersFeatureFlags.
//     Insiders is a server-controlled meta switch, so its expansion is NOT
//     re-validated against AllowedFeatureFlags.
//
// AllowedFeatureFlags and InsidersFeatureFlags are independent sets:
//   - A flag in AllowedFeatureFlags but not InsidersFeatureFlags is a regular
//     opt-in flag that insiders mode does not turn on automatically.
//   - A flag in InsidersFeatureFlags but not AllowedFeatureFlags is reachable
//     only through insiders mode and cannot be enabled by user input.
//
// Returns a set (map) for O(1) lookup by the feature checker.
func ResolveFeatureFlags(enabledFeatures []string, insidersMode bool) map[string]bool {
	effective := make(map[string]bool)
	for _, feature := range enabledFeatures {
		if slices.Contains(AllowedFeatureFlags, feature) {
			effective[feature] = true
		}
	}
	if insidersMode {
		for _, f := range InsidersFeatureFlags {
			effective[f] = true
		}
	}
	return effective
}
